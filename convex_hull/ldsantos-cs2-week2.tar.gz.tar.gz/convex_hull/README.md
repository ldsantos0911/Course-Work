Caltech CS2 Assignment 2: Sorting and Convex Hull

See [assignment2.html](http://htmlpreview.github.io/?https://github.com/caltechcs2/convex_hull/blob/master/assignment2.html)
