Caltech CS2 Assignment 7: Network Programming

See [assignment7.html](http://htmlpreview.github.io/?https://github.com/caltechcs2/networking/blob/master/assignment7.html)
